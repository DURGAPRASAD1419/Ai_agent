# Research-App - Research Paper Analysis Application

## Overview
This MERN stack application was generated based on the analysis of a research paper. It provides functionality for uploading, analyzing, and managing research papers.

## Features
- User Management
- Authentication System
- Dashboard
- Analytics & Reporting
- Admin Panel

## Tech Stack
- **Frontend**: React.js
- **Backend**: Node.js, Express.js
- **Database**: MongoDB
- **Authentication**: JWT

## Installation

### Backend Setup
1. Navigate to backend directory: `cd backend`
2. Install dependencies: `npm install`
3. Create a `.env` file with your configuration
4. Start the server: `npm run dev`

### Frontend Setup
1. Navigate to frontend directory: `cd frontend`
2. Install dependencies: `npm install`
3. Start the development server: `npm start`

## API Endpoints
- `GET /api/research` - Get all research papers
- `POST /api/research` - Create new research paper
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login

## Generated Features
Based on the research paper analysis, the following features were identified and implemented:
- User Management
- Authentication System
- Dashboard
- Analytics & Reporting
- Admin Panel

## Key Concepts Extracted
- This
- Node
- React
- The
- It
